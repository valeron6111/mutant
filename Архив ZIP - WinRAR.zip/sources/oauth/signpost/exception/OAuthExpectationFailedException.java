package oauth.signpost.exception;

/* loaded from: classes.dex */
public class OAuthExpectationFailedException extends OAuthException {
    public OAuthExpectationFailedException(String message) {
        super(message);
    }
}
