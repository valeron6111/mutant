package org.cocos2dx.lib;

/* compiled from: Cocos2dxActivity.java */
/* loaded from: classes.dex */
class DialogMessage {
    public String message;
    public String title;

    public DialogMessage(String title, String message) {
        this.message = message;
        this.title = title;
    }
}
