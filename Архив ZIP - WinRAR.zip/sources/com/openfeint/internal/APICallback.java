package com.openfeint.internal;

/* loaded from: classes.dex */
public abstract class APICallback {
    public void onFailure(String exceptionMessage) {
    }
}
