package com.openfeint.internal.resource;

/* loaded from: classes.dex */
public abstract class ResourceProperty {
}
