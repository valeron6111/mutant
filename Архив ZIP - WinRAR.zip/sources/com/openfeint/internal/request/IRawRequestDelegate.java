package com.openfeint.internal.request;

/* loaded from: classes.dex */
public interface IRawRequestDelegate {
    void onResponse(int i, String str);
}
