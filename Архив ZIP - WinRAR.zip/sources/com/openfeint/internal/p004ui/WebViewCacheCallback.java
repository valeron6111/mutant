package com.openfeint.internal.p004ui;

/* loaded from: classes.dex */
public abstract class WebViewCacheCallback {
    public abstract void failLoaded();

    public abstract void pathLoaded(String str);

    public void onTrackingNeeded() {
    }
}
