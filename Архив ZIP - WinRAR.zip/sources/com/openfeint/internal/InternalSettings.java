package com.openfeint.internal;

/* loaded from: classes.dex */
public class InternalSettings {
    public static final String WebUIDelayUntilCopyFinished = "com.openfeint.internal.InternalSettings.WebUIDelayUntilCopyFinished";
}
