package com.openfeint.api;

/* renamed from: com.openfeint.api.R */
/* loaded from: classes.dex */
public final class C0110R {

    /* renamed from: com.openfeint.api.R$attr */
    public static final class attr {
    }

    /* renamed from: com.openfeint.api.R$color */
    public static final class color {
        public static final int dark_grey = 2130968584;
        public static final int error_message = 2130968578;
        public static final int of_transparent = 2130968576;
        public static final int rewards_background = 2130968579;
        public static final int rewards_description = 2130968581;
        public static final int rewards_text = 2130968580;
        public static final int screen_background = 2130968577;
        public static final int share_background = 2130968582;
        public static final int share_text = 2130968583;
        public static final int white = 2130968585;
    }

    /* renamed from: com.openfeint.api.R$dimen */
    public static final class dimen {
        public static final int get_reward_button_margin_right = 2131165190;
        public static final int get_reward_button_width = 2131165189;
        public static final int get_reward_row_height = 2131165186;
        public static final int get_reward_row_width = 2131165185;
        public static final int get_reward_width = 2131165184;
        public static final int gift_code_edit_width = 2131165191;
        public static final int promo_code_get_code_text_width = 2131165193;
        public static final int promo_code_tab_row_height = 2131165192;
        public static final int reward_tab_description_width = 2131165188;
        public static final int reward_tab_row_height = 2131165187;
        public static final int rewards_button_description_size = 2131165197;
        public static final int rewards_button_text_size = 2131165198;
        public static final int rewards_button_title_size = 2131165196;
        public static final int rewards_height = 2131165195;
        public static final int rewards_width = 2131165194;
        public static final int share_button_width = 2131165201;
        public static final int share_text_size = 2131165200;
        public static final int share_title_size = 2131165199;
        public static final int social_button_size = 2131165202;
    }

    /* renamed from: com.openfeint.api.R$drawable */
    public static final class drawable {
        public static final int back_letter_all_landscape = 2130837504;
        public static final int backgr = 2130837505;
        public static final int border = 2130837506;
        public static final int button_backtomenu = 2130837507;
        public static final int button_close = 2130837508;
        public static final int button_subscribe = 2130837509;
        public static final int close = 2130837510;
        public static final int facebook = 2130837511;
        public static final int facebook_button = 2130837512;
        public static final int facebook_icon = 2130837513;
        public static final int frame_layout_shape = 2130837514;
        public static final int green_button_down = 2130837515;
        public static final int green_button_up = 2130837516;
        public static final int icon = 2130837517;
        public static final int left_border = 2130837518;
        public static final int logo_alawar = 2130837519;
        public static final int logo_alawar_old = 2130837520;
        public static final int of_achievement_icon_frame = 2130837521;
        public static final int of_achievement_icon_locked = 2130837522;
        public static final int of_achievement_icon_unlocked = 2130837523;
        public static final int of_achievement_notification_bkg = 2130837524;
        public static final int of_achievement_notification_locked = 2130837525;
        public static final int of_feint_points_white = 2130837526;
        public static final int of_icon_dashboard_exit = 2130837527;
        public static final int of_icon_dashboard_home = 2130837528;
        public static final int of_icon_dashboard_settings = 2130837529;
        public static final int of_icon_highscore_notification = 2130837530;
        public static final int of_ll_logo = 2130837531;
        public static final int of_native_loader = 2130837532;
        public static final int of_native_loader_frame = 2130837533;
        public static final int of_native_loader_leaf = 2130837534;
        public static final int of_native_loader_progress = 2130837535;
        public static final int of_native_loader_progress_01 = 2130837536;
        public static final int of_native_loader_progress_02 = 2130837537;
        public static final int of_native_loader_progress_03 = 2130837538;
        public static final int of_native_loader_progress_04 = 2130837539;
        public static final int of_native_loader_progress_05 = 2130837540;
        public static final int of_native_loader_progress_06 = 2130837541;
        public static final int of_native_loader_progress_07 = 2130837542;
        public static final int of_native_loader_progress_08 = 2130837543;
        public static final int of_native_loader_progress_09 = 2130837544;
        public static final int of_native_loader_progress_10 = 2130837545;
        public static final int of_native_loader_progress_11 = 2130837546;
        public static final int of_native_loader_progress_12 = 2130837547;
        public static final int of_notification_bkg = 2130837548;
        public static final int ofadbadge = 2130837549;
        public static final int ofgamebarachievementicon = 2130837550;
        public static final int ofgamebarcelldividerlandscape = 2130837551;
        public static final int ofgamebarcelldividerportrait = 2130837552;
        public static final int ofgamebardeveloperannouncement = 2130837553;
        public static final int ofgamebarlargedisclosure = 2130837554;
        public static final int ofgamebarleaderboardsicon = 2130837555;
        public static final int ofgamebaroffline = 2130837556;
        public static final int ofgamebarparentalcontrolsicon = 2130837557;
        public static final int ofgamebarprofileframe = 2130837558;
        public static final int ofgamebarprofileframesmall = 2130837559;
        public static final int ofgamebarprofileicon = 2130837560;
        public static final int ofgamebarservererroricon = 2130837561;
        public static final int ofgamebarsmalldisclosure = 2130837562;
        public static final int ofgamebarstartopenfeint = 2130837563;
        public static final int ofgamefeedbackgroundbottom = 2130837564;
        public static final int ofgamefeedbackgroundbottomlandscape = 2130837565;
        public static final int ofgamefeedbadgeicon = 2130837566;
        public static final int ofgamefeedbadgeiconhit = 2130837567;
        public static final int ofgamefeedbadgeiconlandscape = 2130837568;
        public static final int ofgamefeedbadgeiconlandscapehit = 2130837569;
        public static final int ofgamefeedviewbackgroundtoplandscape = 2130837570;
        public static final int ofgamefeedviewbackgroundtopportrait = 2130837571;
        public static final int ofgfihitlandscape = 2130837572;
        public static final int ofgfihitportrait = 2130837573;
        public static final int oflandscapeadbordercell = 2130837574;
        public static final int ofportraitadbordercell = 2130837575;
        public static final int ofregularfulllandscape = 2130837576;
        public static final int ofregularfullportrait = 2130837577;
        public static final int ofspinnergray = 2130837578;
        public static final int ofspinnergray01 = 2130837579;
        public static final int ofspinnergray02 = 2130837580;
        public static final int ofspinnergray03 = 2130837581;
        public static final int ofspinnergray04 = 2130837582;
        public static final int ofspinnergray05 = 2130837583;
        public static final int ofspinnergray06 = 2130837584;
        public static final int ofspinnergray07 = 2130837585;
        public static final int ofspinnergray08 = 2130837586;
        public static final int ofspinnergray09 = 2130837587;
        public static final int ofspinnergray10 = 2130837588;
        public static final int ofspinnergray11 = 2130837589;
        public static final int ofspinnergray12 = 2130837590;
        public static final int top = 2130837591;
        public static final int twitter = 2130837592;
        public static final int twitter_button = 2130837593;
        public static final int yellow_button = 2130837594;
        public static final int yellow_button_down = 2130837595;
        public static final int yellow_button_up = 2130837596;
    }

    /* renamed from: com.openfeint.api.R$id */
    public static final class id {
        public static final int NewsletterLayout = 2131296330;
        public static final int add_notification_button = 2131296280;
        public static final int alawar_subscriber_BackButton = 2131296256;
        public static final int alawar_subscriber_EmailEditText = 2131296260;
        public static final int alawar_subscriber_InfoTextView = 2131296257;
        public static final int alawar_subscriber_NameEditText = 2131296259;
        public static final int alawar_subscriber_PrivacyTextView = 2131296264;
        public static final int alawar_subscriber_SubscribeButton = 2131296261;
        public static final int alawar_subscriber_SubscribeLayout = 2131296258;
        public static final int alawar_subscriber_ThankButton = 2131296263;
        public static final int alawar_subscriber_ThankLayout = 2131296262;
        public static final int back_button_1 = 2131296318;
        public static final int back_button_2 = 2131296320;
        public static final int back_button_3 = 2131296324;
        public static final int balance_button = 2131296276;
        public static final int billing_supported = 2131296284;
        public static final int buy_button = 2131296285;
        public static final int description = 2131296266;
        public static final int exit_feint = 2131296333;
        public static final int facebook_login_button = 2131296281;
        public static final int frameLayout = 2131296303;
        public static final int get_gift_button = 2131296272;
        public static final int get_promo_button = 2131296323;
        public static final int get_promo_code_button = 2131296313;
        public static final int get_reward_button = 2131296279;
        public static final int get_reward_layout = 2131296268;
        public static final int gift_code = 2131296271;
        public static final int gift_code_button = 2131296269;
        public static final int gift_code_tab = 2131296319;
        public static final int home = 2131296331;
        public static final int installation_id = 2131296315;
        public static final int invite_friends_button = 2131296270;
        public static final int invite_friends_facebook = 2131296316;
        public static final int invite_friends_tab = 2131296314;
        public static final int invite_friends_twitter = 2131296317;
        public static final int item_choices = 2131296286;
        public static final int item_name = 2131296273;
        public static final int item_quantity = 2131296274;
        public static final int log = 2131296289;
        public static final int logo_image = 2131296329;
        public static final int message = 2131296265;
        public static final int more_games_button = 2131296291;
        public static final int mutant_gl_surfaceview = 2131296292;
        public static final int nested_window_root = 2131296302;
        public static final int newsletter_subscription_button = 2131296290;
        public static final int of_achievement_icon = 2131296295;
        public static final int of_achievement_icon_frame = 2131296296;
        public static final int of_achievement_notification = 2131296294;
        public static final int of_achievement_progress_icon = 2131296300;
        public static final int of_achievement_score = 2131296298;
        public static final int of_achievement_score_icon = 2131296299;
        public static final int of_achievement_text = 2131296297;
        public static final int of_icon = 2131296306;
        public static final int of_ll_logo_image = 2131296305;
        public static final int of_text = 2131296307;
        public static final int of_text1 = 2131296308;
        public static final int of_text2 = 2131296309;
        public static final int offerwall_button = 2131296277;
        public static final int openfeint_achievements_button = 2131296283;
        public static final int owned_items = 2131296288;
        public static final int payload_edit_button = 2131296287;
        public static final int payload_text = 2131296267;
        public static final int progress = 2131296301;
        public static final int promo_code = 2131296322;
        public static final int promo_code_button = 2131296312;
        public static final int promo_code_tab = 2131296321;
        public static final int rewards_buttons_tab = 2131296311;
        public static final int rewards_tabhost = 2131296310;
        public static final int settings = 2131296332;
        public static final int share_with_friends_facebook = 2131296326;
        public static final int share_with_friends_text = 2131296325;
        public static final int share_with_friends_twitter = 2131296327;
        public static final int splash_screen = 2131296328;
        public static final int subscription_button = 2131296278;
        public static final int test_ach = 2131296275;
        public static final int textField = 2131296293;
        public static final int twitter_login_button = 2131296282;
        public static final int web_view = 2131296304;
    }

    /* renamed from: com.openfeint.api.R$layout */
    public static final class layout {
        public static final int alawar_subscriber_layout = 2130903040;
        public static final int billing_not_supported = 2130903041;
        public static final int edit_payload = 2130903042;
        public static final int get_reward = 2130903043;
        public static final int gift_code = 2130903044;
        public static final int item_row = 2130903045;
        public static final int main = 2130903046;
        public static final int more_games = 2130903047;
        public static final int mutant = 2130903048;
        public static final int of_achievement_notification = 2130903049;
        public static final int of_native_loader = 2130903050;
        public static final int of_nested_window = 2130903051;
        public static final int of_simple_notification = 2130903052;
        public static final int of_two_line_notification = 2130903053;
        public static final int progressbar = 2130903054;
        public static final int rewards = 2130903055;
        public static final int share = 2130903056;
        public static final int splash_screen = 2130903057;
        public static final int subscriber_layout = 2130903058;
    }

    /* renamed from: com.openfeint.api.R$menu */
    public static final class menu {
        public static final int of_dashboard = 2131230720;
    }

    /* renamed from: com.openfeint.api.R$string */
    public static final class string {
        public static final int actions = 2131034227;
        public static final int alawar_subscriber_accepted = 2131034205;
        public static final int alawar_subscriber_back = 2131034206;
        public static final int alawar_subscriber_email_hint = 2131034207;
        public static final int alawar_subscriber_error_title = 2131034210;
        public static final int alawar_subscriber_info = 2131034201;
        public static final int alawar_subscriber_invalid_email_text = 2131034211;
        public static final int alawar_subscriber_name_hint = 2131034208;
        public static final int alawar_subscriber_ok = 2131034213;
        public static final int alawar_subscriber_privacy = 2131034202;
        public static final int alawar_subscriber_request_failed = 2131034212;
        public static final int alawar_subscriber_subscribe = 2131034203;
        public static final int alawar_subscriber_thanks = 2131034204;
        public static final int alawar_subscriber_title = 2131034200;
        public static final int alawar_subscriber_wait = 2131034209;
        public static final int android_test_canceled = 2131034223;
        public static final int android_test_item_unavailable = 2131034225;
        public static final int android_test_purchased = 2131034224;
        public static final int android_test_refunded = 2131034226;
        public static final int app_name = 2131034157;
        public static final int back_button = 2131034183;
        public static final int buy = 2131034214;
        public static final int edit_payload = 2131034216;
        public static final int edit_payload_accept = 2131034218;
        public static final int edit_payload_clear = 2131034219;
        public static final int edit_payload_title = 2131034217;
        public static final int facebook_button = 2131034185;
        public static final int facebook_login = 2131034228;
        public static final int get_promo_code = 2131034181;
        public static final int get_reward = 2131034231;
        public static final int get_reward_title = 2131034168;
        public static final int gift_code = 2131034160;
        public static final int gift_code_description = 2131034175;
        public static final int gift_code_description_full = 2131034176;
        public static final int gift_code_message_facebook = 2131034190;
        public static final int gift_code_message_twitter = 2131034191;
        public static final int gift_code_title = 2131034169;
        public static final int gift_code_title_cap = 2131034174;
        public static final int gift_fail = 2131034162;
        public static final int gift_success = 2131034163;
        public static final int hello = 2131034156;
        public static final int internet_not_available = 2131034198;
        public static final int invite_friends = 2131034171;
        public static final int invite_friends_button = 2131034173;
        public static final int invite_friends_description = 2131034172;
        public static final int invite_friends_title_cap = 2131034182;
        public static final int items_for_sale = 2131034220;
        public static final int items_you_own = 2131034221;
        public static final int more_games = 2131034195;
        public static final int more_games_button = 2131034197;
        public static final int more_games_description = 2131034196;
        public static final int newsletter_subscription = 2131034192;
        public static final int newsletter_subscription_button = 2131034194;
        public static final int newsletter_subscription_description = 2131034193;
        public static final int of_achievement_load_null = 2131034120;
        public static final int of_achievement_unlock_null = 2131034119;
        public static final int of_achievement_unlocked = 2131034136;
        public static final int of_banned_dialog = 2131034149;
        public static final int of_bitmap_decode_error = 2131034138;
        public static final int of_cancel = 2131034132;
        public static final int of_cant_compress_blob = 2131034134;
        public static final int of_crash_report_query = 2131034146;
        public static final int of_device = 2131034127;
        public static final int of_error_parsing_error_message = 2131034140;
        public static final int of_exit_feint = 2131034151;
        public static final int of_file_not_found = 2131034139;
        public static final int of_home = 2131034148;
        public static final int of_id_cannot_be_null = 2131034114;
        public static final int of_io_exception_on_download = 2131034133;
        public static final int of_ioexception_reading_body = 2131034142;
        public static final int of_key_cannot_be_null = 2131034112;
        public static final int of_loading_feint = 2131034128;
        public static final int of_low_memory_profile_pic = 2131034122;
        public static final int of_malformed_request_error = 2131034155;
        public static final int of_name_cannot_be_null = 2131034115;
        public static final int of_no = 2131034129;
        public static final int of_no_blob = 2131034135;
        public static final int of_no_video = 2131034147;
        public static final int of_nodisk = 2131034124;
        public static final int of_now_logged_in_as_format = 2131034144;
        public static final int of_null_icon_url = 2131034118;
        public static final int of_offline_notification = 2131034152;
        public static final int of_offline_notification_line2 = 2131034153;
        public static final int of_ok = 2131034131;
        public static final int of_operation_not_permitted_due_to_parental_controls = 2131034125;
        public static final int of_profile_pic_changed = 2131034145;
        public static final int of_profile_picture_download_failed = 2131034123;
        public static final int of_profile_url_null = 2131034121;
        public static final int of_score_submitted_notification = 2131034154;
        public static final int of_sdcard = 2131034126;
        public static final int of_secret_cannot_be_null = 2131034113;
        public static final int of_server_error_code_format = 2131034141;
        public static final int of_settings = 2131034150;
        public static final int of_switched_accounts = 2131034143;
        public static final int of_timeout = 2131034137;
        public static final int of_unexpected_response_format = 2131034116;
        public static final int of_unknown_server_error = 2131034117;
        public static final int of_yes = 2131034130;
        public static final int openfeint_achievements = 2131034234;
        public static final int openfeint_not_logged_in = 2131034199;
        public static final int progress_text = 2131034159;
        public static final int promo_code = 2131034178;
        public static final int promo_code_description = 2131034180;
        public static final int promo_code_get_code_text = 2131034179;
        public static final int promo_code_title = 2131034170;
        public static final int promo_code_title_cap = 2131034177;
        public static final int promo_fail = 2131034166;
        public static final int promo_success = 2131034167;
        public static final int recent_transactions = 2131034222;
        public static final int request_progress = 2131034189;
        public static final int restoring_transactions = 2131034158;
        public static final int rewards = 2131034230;
        public static final int select_item = 2131034215;
        public static final int share_with_friends_text = 2131034188;
        public static final int share_with_friends_title_cap = 2131034187;
        public static final int submit_gift_code = 2131034161;
        public static final int submit_promo_code = 2131034165;
        public static final int subscription = 2131034233;
        public static final int test_ach = 2131034232;
        public static final int twitter_button = 2131034186;
        public static final int twitter_login = 2131034229;
        public static final int visit_page = 2131034164;
        public static final int your_code = 2131034184;
    }

    /* renamed from: com.openfeint.api.R$style */
    public static final class style {
        public static final int FacebookButton = 2131099652;
        public static final int GreenButton = 2131099651;
        public static final int OFLoading = 2131099648;
        public static final int OFNestedWindow = 2131099649;
        public static final int TwitterButton = 2131099653;
        public static final int YellowButton = 2131099650;
    }
}
