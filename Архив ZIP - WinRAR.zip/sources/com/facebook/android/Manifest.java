package com.facebook.android;

/* loaded from: classes.dex */
public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.alawar.mutant.permission.C2D_MESSAGE";
    }
}
