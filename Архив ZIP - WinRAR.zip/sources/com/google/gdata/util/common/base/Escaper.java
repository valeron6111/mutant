package com.google.gdata.util.common.base;

/* loaded from: classes.dex */
public interface Escaper {
    Appendable escape(Appendable appendable);

    String escape(String str);
}
