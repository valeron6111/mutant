package com.alawar.mutant;

/* loaded from: classes.dex */
public interface OnPostInitialization {
    void onPostInitialization();
}
