package com.alawar.mutant.thirdparty;

/* loaded from: classes.dex */
public enum FeedPostResult {
    OK,
    ERROR,
    AUTH_ERROR
}
