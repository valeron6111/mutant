package com.alawar.mutant.thirdparty.openfeint;

/* loaded from: classes.dex */
public interface OpenFeintClientInitializedCallback {
    void onFinish();
}
