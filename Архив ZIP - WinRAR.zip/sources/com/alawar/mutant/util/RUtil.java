package com.alawar.mutant.util;

import android.content.Context;

/* loaded from: classes.dex */
public class RUtil {
    public static String getString(Context context, int id) {
        return context.getResources().getString(id);
    }
}
