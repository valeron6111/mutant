package com.alawar.mutant.util;

/* loaded from: classes.dex */
public interface ParametrizedRunnable<T> {
    void run(T t);
}
