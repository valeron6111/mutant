package com.alawar.mutant.network;

/* loaded from: classes.dex */
public class Coins {
    public int amount;

    public Coins(int amount) {
        this.amount = amount;
    }
}
