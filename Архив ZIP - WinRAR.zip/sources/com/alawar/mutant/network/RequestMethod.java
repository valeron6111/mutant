package com.alawar.mutant.network;

/* loaded from: classes.dex */
public enum RequestMethod {
    GET,
    POST
}
