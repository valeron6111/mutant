package com.alawar.mutant;

/* loaded from: classes.dex */
public class Settings {
    public static final String PACKAGE_NAME = "com.alawar.mutant";
    public static String facebookAppId = "216313258482782";
    public static String appMarketUrl = "https://play.google.com/store/apps/details?id=com.alawar.mutant";
    public static String appMarketShortUrl = "http://bit.ly/KpKMZV";
}
