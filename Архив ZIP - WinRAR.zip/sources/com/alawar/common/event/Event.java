package com.alawar.common.event;

/* loaded from: classes.dex */
public interface Event {
}
