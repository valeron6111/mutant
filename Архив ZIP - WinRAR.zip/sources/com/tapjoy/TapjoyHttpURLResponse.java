package com.tapjoy;

/* loaded from: classes.dex */
public class TapjoyHttpURLResponse {
    public int contentLength;
    public String response;
    public int statusCode;
}
