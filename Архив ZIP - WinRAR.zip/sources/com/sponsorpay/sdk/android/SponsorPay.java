package com.sponsorpay.sdk.android;

/* loaded from: classes.dex */
public class SponsorPay {
    public static final int BUGFIX_RELEASE_NUMBER = 2;
    public static final int MAJOR_RELEASE_NUMBER = 1;
    public static final int MINOR_RELEASE_NUMBER = 8;
    public static final String RELEASE_VERSION_STRING = String.format("%d.%d.%d", 1, 8, 2);
}
