package com.flurry.android;

/* renamed from: com.flurry.android.al */
/* loaded from: classes.dex */
final class C0082al extends AbstractC0080aj {

    /* renamed from: a */
    String f113a;

    /* renamed from: b */
    String f114b;

    /* renamed from: c */
    int f115c;

    C0082al() {
    }
}
