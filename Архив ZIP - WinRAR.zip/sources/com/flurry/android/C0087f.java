package com.flurry.android;

/* renamed from: com.flurry.android.f */
/* loaded from: classes.dex */
final class C0087f {

    /* renamed from: a */
    final byte f185a;

    /* renamed from: b */
    final long f186b;

    C0087f(byte b, long j) {
        this.f185a = b;
        this.f186b = j;
    }

    public final String toString() {
        return "[" + this.f186b + "] " + ((int) this.f185a);
    }
}
