package com.flurry.android;

/* renamed from: com.flurry.android.k */
/* loaded from: classes.dex */
final class RunnableC0092k implements Runnable {

    /* renamed from: a */
    private /* synthetic */ C0077ag f195a;

    RunnableC0092k(C0077ag c0077ag) {
        this.f195a = c0077ag;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f195a.m68a();
    }
}
