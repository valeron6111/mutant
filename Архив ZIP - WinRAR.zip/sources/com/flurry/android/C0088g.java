package com.flurry.android;

/* renamed from: com.flurry.android.g */
/* loaded from: classes.dex */
final class C0088g {

    /* renamed from: a */
    int f187a;

    /* synthetic */ C0088g() {
        this((byte) 0);
    }

    private C0088g(byte b) {
    }
}
