package com.flurry.android;

import android.os.Handler;

/* renamed from: com.flurry.android.a */
/* loaded from: classes.dex */
final class C0070a {

    /* renamed from: a */
    String f82a;

    /* renamed from: b */
    long f83b;

    /* renamed from: c */
    String f84c;

    /* renamed from: d */
    String f85d;

    /* renamed from: e */
    Handler f86e;

    C0070a() {
    }
}
