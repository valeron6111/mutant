package com.flurry.android;

/* renamed from: com.flurry.android.aj */
/* loaded from: classes.dex */
abstract class AbstractC0080aj {
    AbstractC0080aj() {
    }
}
