package com.flurry.android;

/* loaded from: classes.dex */
public interface AppCircleCallback {
    void onAdsUpdated(CallbackEvent callbackEvent);

    void onMarketAppLaunchError(CallbackEvent callbackEvent);
}
