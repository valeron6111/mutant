package com.flurry.android;

import java.util.List;

/* renamed from: com.flurry.android.x */
/* loaded from: classes.dex */
final class C0105x {

    /* renamed from: a */
    String f252a;

    /* renamed from: b */
    List f253b;

    C0105x() {
    }
}
