package com.flurry.android;

/* renamed from: com.flurry.android.aa */
/* loaded from: classes.dex */
final class C0071aa {

    /* renamed from: a */
    long f87a;

    /* renamed from: b */
    String f88b;

    /* renamed from: c */
    String f89c;

    /* renamed from: d */
    String f90d;

    /* synthetic */ C0071aa() {
        this((byte) 0);
    }

    private C0071aa(byte b) {
    }
}
