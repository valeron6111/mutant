// DO NOT EDIT
//   Generated from javascripts/dashboard/dashboard.coffee
//
(function() {
  this.userPicUrl = function(url) {
    if (OF.device.parentalControls) {
      return "images/icon.user.male." + OF.dpi + ".png";
    } else {
      return url;
    }
  };
}).call(this);
